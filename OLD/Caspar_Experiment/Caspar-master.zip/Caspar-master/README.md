# Caspar
Caspar: Extracting and Synthesizing User Stories of Problems from App Reviews

The database file (data/Caspar_Public.db) can be found [here](https://drive.google.com/open?id=1-Tc_S0EvHYiDD4rWp98mXuSwisscK5tf).
Results from SVM classifiers (data/SVM_Results.csv) can be found [here](https://drive.google.com/file/d/17Bwzpm0pvghVdy6SBGSVmnge5A9aeKOF/view?usp=sharing).

To appear in ICSE 2020:

Hui Guo and Munindar P. Singh. **Caspar: Extracting and Synthesizing User Stories of Problems from App Reviews.** *Proceedings of the 42nd IEEE International Conference on Software Engineering (ICSE)*, Seoul, May 2020, 1–13.
